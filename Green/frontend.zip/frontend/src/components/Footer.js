import React from 'react';
import './landing_page_banner.css'; // CSS 파일 import

function Footer() {
    return (
        <div id="footer">          
           <p>&copy; 2024 1팀 홈페이지. All rights reserved.</p>
        </div>
    );
}

export default Footer;
